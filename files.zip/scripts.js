// ===========================
//   حكايا - Hikaya Scripts
//   Historical Stories Website
// ===========================

'use strict';

// === App State ===
const App = {
  stories: [],
  currentPage: 'home',
  currentStory: null,
  currentCategory: null,
  filteredStories: [],

  async init() {
    await this.loadStories();
    this.setupRouting();
    this.hideLoadingScreen();
  },

  async loadStories() {
    try {
      const res = await fetch('stories.json');
      if (!res.ok) throw new Error('Failed to load');
      this.stories = await res.json();
      this.filteredStories = [...this.stories];
    } catch (e) {
      console.warn('Could not load stories.json, using fallback empty array');
      this.stories = [];
      this.filteredStories = [];
    }
  },

  hideLoadingScreen() {
    const screen = document.getElementById('loading-screen');
    if (!screen) return;
    setTimeout(() => {
      screen.classList.add('hidden');
      this.renderHome();
      this.showPage('home');
    }, 1200);
  },

  setupRouting() {
    // Handle browser back/forward
    window.addEventListener('popstate', (e) => {
      if (e.state) {
        this.handleState(e.state);
      } else {
        this.renderHome();
        this.showPage('home');
      }
    });
  },

  handleState(state) {
    if (state.page === 'story') {
      const story = this.stories.find(s => s.id === state.id);
      if (story) this.openStory(story, false);
    } else if (state.page === 'category') {
      this.openCategory(state.category, false);
    } else {
      this.renderHome();
      this.showPage('home');
    }
  },

  showPage(pageId) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => {
      p.classList.remove('active', 'visible');
    });

    const target = document.getElementById('page-' + pageId);
    if (!target) return;

    target.classList.add('active');

    // Trigger animation
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        target.classList.add('visible');
      });
    });

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Update nav active state
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.remove('active');
      if (item.dataset.page === pageId) {
        item.classList.add('active');
      }
    });
  },

  // === Home Page ===
  renderHome() {
    this.filteredStories = [...this.stories];
    this.renderCategories();
    this.renderStoriesGrid('stories-grid-home', this.stories.slice(0, 10));
    this.setupSearch();
    this.setupFilters();
  },

  renderCategories() {
    const categories = [
      {
        name: 'حروب',
        icon: '⚔️',
        color: 'cat-wars',
        bg: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&q=80',
        desc: 'معارك غيّرت التاريخ'
      },
      {
        name: 'ملوك',
        icon: '👑',
        color: 'cat-kings',
        bg: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
        desc: 'سير الحكام والملوك'
      },
      {
        name: 'غرائب',
        icon: '🔮',
        color: 'cat-oddities',
        bg: 'https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=600&q=80',
        desc: 'أغرب ما جرى'
      },
      {
        name: 'أحداث يومية',
        icon: '📜',
        color: 'cat-daily',
        bg: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=600&q=80',
        desc: 'حياة الناس عبر الزمن'
      }
    ];

    const grid = document.getElementById('categories-grid');
    if (!grid) return;

    const counts = {};
    this.stories.forEach(s => {
      counts[s.category] = (counts[s.category] || 0) + 1;
    });

    grid.innerHTML = categories.map(cat => `
      <div class="category-card ${cat.color}" onclick="App.openCategory('${cat.name}')" role="button" tabindex="0" aria-label="${cat.name}">
        <div class="category-bg" style="background-image: url('${cat.bg}')"></div>
        <div class="category-overlay">
          <div class="category-icon">${cat.icon}</div>
          <div class="category-name">${cat.name}</div>
          <div class="category-count">${counts[cat.name] || 0} قصة</div>
        </div>
      </div>
    `).join('');

    // Keyboard accessibility for categories
    grid.querySelectorAll('.category-card').forEach(card => {
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          card.click();
        }
      });
    });
  },

  renderStoriesGrid(containerId, stories) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (!stories || stories.length === 0) {
      container.innerHTML = `
        <div class="no-results" style="grid-column: 1/-1">
          <span class="no-results-icon">📭</span>
          <p>لا توجد قصص في هذا التصنيف بعد</p>
        </div>
      `;
      return;
    }

    container.innerHTML = stories.map(story => this.buildStoryCard(story)).join('');
  },

  buildStoryCard(story) {
    const categoryClass = `badge-${story.category.replace(' ', '.')}`;
    return `
      <article class="story-card" onclick="App.openStory(${JSON.stringify(story).replace(/"/g, '&quot;')})" role="button" tabindex="0" aria-label="${story.title}">
        <div class="story-card-image">
          <img src="${story.image}" alt="${story.title}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=600&q=80'">
          <span class="story-card-badge ${categoryClass}">${story.category}</span>
        </div>
        <div class="story-card-body">
          <span class="story-card-icon">${story.icon}</span>
          <h3 class="story-card-title">${story.title}</h3>
          <p class="story-card-excerpt">${story.excerpt}</p>
          <div class="story-card-footer">
            <span class="story-meta">
              <span>📅</span>
              <span>${story.date}</span>
            </span>
            <button class="read-btn">اقرأ القصة ←</button>
          </div>
        </div>
      </article>
    `;
  },

  // === Story Page ===
  openStory(story, pushState = true) {
    if (typeof story === 'string') {
      story = this.stories.find(s => s.id === parseInt(story));
    }
    if (!story) return;

    this.currentStory = story;

    if (pushState) {
      history.pushState({ page: 'story', id: story.id }, story.title, `#story-${story.id}`);
    }

    this.renderStoryPage(story);
    this.showPage('story');
  },

  renderStoryPage(story) {
    const container = document.getElementById('story-content');
    if (!container) return;

    // Find adjacent stories
    const idx = this.stories.findIndex(s => s.id === story.id);
    const prevStory = idx > 0 ? this.stories[idx - 1] : null;
    const nextStory = idx < this.stories.length - 1 ? this.stories[idx + 1] : null;

    // Format story content into paragraphs
    const paragraphs = story.content.split('\n\n').filter(p => p.trim());
    const contentHtml = paragraphs.map(p => `<p>${p.trim()}</p>`).join('');

    const tagClass = `tag-${story.category.replace(' ', '\\ ')}`;

    container.innerHTML = `
      <button class="story-back-btn" onclick="App.goBack()">
        <span class="arrow">→</span>
        <span>العودة للرئيسية</span>
      </button>

      <div class="story-hero">
        <img src="${story.image}" alt="${story.title}" onerror="this.src='https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=1200&q=80'">
        <div class="story-hero-overlay">
          <span class="story-category-tag tag-${story.category}">${story.category}</span>
          <h1 class="story-hero-title">${story.title}</h1>
        </div>
      </div>

      <article class="story-article">
        <div class="story-meta-bar">
          <span class="story-icon-large">${story.icon}</span>
          <span class="story-meta-item">
            <span>📅</span>
            <span>${story.date}</span>
          </span>
          <span class="story-meta-item">
            <span>⏱️</span>
            <span>وقت القراءة: ${story.readTime}</span>
          </span>
          <span class="story-meta-item">
            <span>🏷️</span>
            <span>${story.category}</span>
          </span>
        </div>

        <div class="story-content">
          ${contentHtml}
        </div>

        <hr class="divider">
        <div class="ornament-divider">❦ ✦ ❦</div>

        <!-- ============================================
             GOOGLE ADSENSE - STORY PAGE (In-Article Ad)
             Replace this section with your AdSense code:
             <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXX" crossorigin="anonymous"></script>
             <ins class="adsbygoogle" style="display:block; text-align:center;" data-ad-layout="in-article" data-ad-format="fluid" data-ad-client="ca-pub-XXXXXXXX" data-ad-slot="XXXXXXXX"></ins>
             ============================================ -->
        <div class="adsense-banner">
          <div>
            <span class="ad-label">إعلان</span>
            <span>مساحة إعلانية - Google AdSense</span>
          </div>
        </div>

        <div class="story-nav">
          ${prevStory ? `
            <div class="story-nav-btn" onclick="App.openStory(${JSON.stringify(prevStory).replace(/"/g, '&quot;')})">
              <span class="nav-label">← القصة السابقة</span>
              <span class="nav-title">${prevStory.title}</span>
            </div>
          ` : '<div></div>'}
          ${nextStory ? `
            <div class="story-nav-btn" onclick="App.openStory(${JSON.stringify(nextStory).replace(/"/g, '&quot;')})">
              <span class="nav-label">القصة التالية →</span>
              <span class="nav-title">${nextStory.title}</span>
            </div>
          ` : '<div></div>'}
        </div>
      </article>
    `;
  },

  goBack() {
    if (history.length > 1) {
      history.back();
    } else {
      this.renderHome();
      this.showPage('home');
    }
  },

  // === Category Page ===
  openCategory(categoryName, pushState = true) {
    this.currentCategory = categoryName;

    if (pushState) {
      history.pushState({ page: 'category', category: categoryName }, categoryName, `#cat-${encodeURIComponent(categoryName)}`);
    }

    this.renderCategoryPage(categoryName);
    this.showPage('category');
  },

  renderCategoryPage(categoryName) {
    const container = document.getElementById('category-content');
    if (!container) return;

    const categoryMeta = {
      'حروب': {
        icon: '⚔️',
        bg: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&q=80',
        desc: 'معارك غيّرت مجرى التاريخ وأسقطت الممالك وأقامت الإمبراطوريات'
      },
      'ملوك': {
        icon: '👑',
        bg: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1200&q=80',
        desc: 'سير الملوك والحكام الذين تركوا بصماتهم على الحضارات'
      },
      'غرائب': {
        icon: '🔮',
        bg: 'https://images.unsplash.com/photo-1509316785289-025f5b846b35?w=1200&q=80',
        desc: 'أغرب وأعجب ما جرى في التاريخ الإنساني'
      },
      'أحداث يومية': {
        icon: '📜',
        bg: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=1200&q=80',
        desc: 'حياة الناس العاديين وأحداثهم اليومية عبر العصور'
      }
    };

    const meta = categoryMeta[categoryName] || { icon: '📖', bg: '', desc: '' };
    const filtered = this.stories.filter(s => s.category === categoryName);

    container.innerHTML = `
      <div class="category-header">
        <div class="category-header-bg" style="background-image: url('${meta.bg}')"></div>
        <div class="category-header-content">
          <span class="category-header-icon">${meta.icon}</span>
          <h2 class="category-header-title">${categoryName}</h2>
          <p style="color: rgba(255,255,255,0.7); font-family: 'Cairo', sans-serif; font-size: 0.95rem; margin-top: 0.75rem; max-width: 500px; margin-inline: auto; line-height: 1.8;">${meta.desc}</p>
        </div>
      </div>

      <div class="container" style="padding-top: 2rem; padding-bottom: 2rem;">
        <button class="story-back-btn" onclick="App.renderHome(); App.showPage('home')" style="margin-bottom: 1.5rem;">
          <span class="arrow">→</span>
          <span>العودة للرئيسية</span>
        </button>

        <p style="font-family: 'Cairo', sans-serif; font-size: 0.9rem; color: var(--text-muted); margin-bottom: 1.5rem;">${filtered.length} قصة في هذا التصنيف</p>

        <!-- ============================================
             GOOGLE ADSENSE - CATEGORY PAGE (Top Banner)
             Replace with your AdSense code here
             ============================================ -->
        <div class="adsense-banner">
          <div>
            <span class="ad-label">إعلان</span>
            <span>مساحة إعلانية - Google AdSense</span>
          </div>
        </div>

        <div class="stories-grid" id="category-stories-grid">
          ${filtered.length > 0
            ? filtered.map(story => this.buildStoryCard(story)).join('')
            : '<div class="no-results" style="grid-column: 1/-1"><span class="no-results-icon">📭</span><p>لا توجد قصص في هذا التصنيف بعد</p></div>'
          }
        </div>
      </div>
    `;
  },

  // === Search ===
  setupSearch() {
    const input = document.getElementById('search-input');
    if (!input) return;

    let timeout;
    input.addEventListener('input', () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        this.filterStories(input.value.trim(), this.currentCategory);
      }, 300);
    });
  },

  setupFilters() {
    document.querySelectorAll('.filter-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');

        const cat = chip.dataset.category;
        this.currentCategory = cat === 'all' ? null : cat;

        const searchInput = document.getElementById('search-input');
        const query = searchInput ? searchInput.value.trim() : '';
        this.filterStories(query, this.currentCategory);
      });
    });
  },

  filterStories(query, category) {
    let results = [...this.stories];

    if (category) {
      results = results.filter(s => s.category === category);
    }

    if (query) {
      const q = query.toLowerCase();
      results = results.filter(s =>
        s.title.toLowerCase().includes(q) ||
        s.excerpt.toLowerCase().includes(q) ||
        s.content.toLowerCase().includes(q)
      );
    }

    this.renderStoriesGrid('stories-grid-home', results);
  },

  // === Nav click handler ===
  handleNavClick(page) {
    if (page === 'home') {
      this.renderHome();
      this.showPage('home');
      history.pushState({ page: 'home' }, 'حكايا', '#');
    } else {
      this.openCategory(page);
    }
  }
};

// === DOM Ready ===
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});

// === Handle keyboard accessibility on story cards ===
document.addEventListener('keydown', (e) => {
  if (e.target.classList.contains('story-card') && (e.key === 'Enter' || e.key === ' ')) {
    e.target.click();
  }
});
